"""This library holds some useful code and gui components that can be used with any tkinter  application"""
