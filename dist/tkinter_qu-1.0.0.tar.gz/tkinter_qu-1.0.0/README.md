This is a library that makes working with Tkinter and by extension making python GUI's a bit easier. This has many 
helper classes that do the heavy lifting for you. The main thing that this project accomplishes is the ability to 
do VIM motions with a tkinter application.

https://micah-ribbens.github.io/Tkinter-Qu/