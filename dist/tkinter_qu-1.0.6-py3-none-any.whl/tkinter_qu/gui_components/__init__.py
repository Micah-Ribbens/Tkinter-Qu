"""This module holds all the GUI components of the application. Most of the GUI components just have one some additional
feature on top of the base tkinter component"""
